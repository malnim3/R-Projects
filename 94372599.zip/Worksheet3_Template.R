## Worksheet 3
## Name: 


## Question 1 - Initialize Variable sample_size to 5 and sample_means to 0.
sample_size <- 5
sample_means <- 0
	
## Question 2 - For loop: mean of a random exponential sample
for(i in 1:500){
  sample_means[i] <- rexp(sample_size, 1.6)
}
	
## Question 3 - Histogram / QQ Plot / Shapiro-Wilk Test
	# a) Histogram for sample_means, with appropriate labels (make sure to export the graphs and submit them to Gradescope)
		# Code:
    hist(sample_means)

		# Explain in detail why you would suspect the data does or does not come from a normal distribution based on the shape of the histogram.
    #I believe this data is not from a normal distribution since the data seems
    #to be skewed to the right.
	
	# b) QQ Plot (make sure to export the graphs and submit them to Gradescope)
		# Code:
    qqplot(c(0.0:max(sample_means)),sample_means)
	
		# Explain in detail why you would suspect the data does or does not come from a normal distribution based on the qq-plot
	  #I do not believe this comes from a normal distribution since the 
    #data curves upwards from the origin. If this was normal then the data would
    #be in a diagonal line from the origin to the top right corner.
	
	# c) Shapiro-Wilk Test
		# Hypothesis Testing Statements:
    # if the test outputs < 0.05 then it is not normal
    # p < 0.05 -> not normal
		# Code:
    shapiro.test(sample_means)
    
		# Copy and paste results here
    #Shapiro-Wilk normality test
    
    #data:  sample_means
    #W = 0.84899, p-value < 2.2e-16

		# Explain in detail why you would suspect the data does or does not come from a normal distribution based on the results of the test.
    # Since the test gave us a p value of 2.2e-16 and this p value is smaller than
    #0.05, I do not believe this comes from a normal distribution

## Question 4 - Initialize Variable sample_size to 300 and sample_means to 0
    sample_size <- 300
    sample_means <- 0
		
## Question 5 - Rerun loop from Question 2 with values from Question 4
	# Insert code here
    for(i in 1:500){
      sample_means[i] <- rexp(sample_size, 1.6)
    }

## Question 6 - Histogram / QQ Plot / Shapiro-Wilk Test
	# a) Histogram for sample_means, with appropriate labels (make sure to export the graphs and submit them to Gradescope)
		# Code:
    hist(sample_means)
		# Explain in detail why you would suspect the data does or does not come from a normal distribution based on the shape of the histogram.
	  #I do not believe this comes from a normal distribution since the hist
    #is not in a bell shaped curve. It seams to be skewed to the right

	# b) QQ Plot (make sure to export the graphs and submit them to Gradescope)
		# Code:
    qqplot(c(0.0:max(sample_means)), sample_means)
    
		# Explain in detail why you would suspect the data does or does not come from a normal distribution based on the qq-plot
    #This qqplot shows the data curving upwards which leads me to believe the data 
    #is not 

	# c) Shapiro-Wilk Test
		# Hypothesis Testing Statements:
    # if the test outputs < 0.05 then it is not normal
    # p < 0.05 -> not normal
  
		# Code:
    shapiro.test(sample_means)

		# Copy and paste results here
   # Shapiro-Wilk normality test
    
    #data:  sample_means
    #W = 0.82778, p-value < 2.2e-16

		# Explain in detail why you would suspect the data does or does not come from a normal distribution based on the results of the test.
    #Since the pvalue given was 2.2e-16 and 2.2e-16 < 0.05, I believe this 
    #data does not coem from a normal distribution

## Question 7 - Do the results coincide with what you would expect from the CLT?  Explain.
    #No it does not because the clt would have been a normal distribution 
		
## Note: Task 2 Setup:
		# H0: p = 0.6
		# H1: p > 0.6
		# To test this hypothesis, n = 1000 individuals are chosen from the population.
		

## Question 8 - Vector population_proportions containing values from 0.6 to 0.7 by 0.001.
population_proportions <- seq(0.60, 0.70, 0.001)
		
## Question 9 - Standardized Critical Values for significance levels 0.05 and 0.01
	# Code for significance level 0.05
  #0.05  cv is +/- 1.959964
  qnorm(.05/2, lower.tail=TRUE)
	# Code for significance level 0.01
  #0.01  cv is +/- 2.326348
  qnorm(.01/2, lower.tail=TRUE)	
		
## Question 10 - Critical Value Computations
  p_5 <- 0.6 + 1.959964 * sqrt((0.6*0.4)/1000)
	p_1 <- 0.6 + 2.326348 * sqrt((0.6*0.4)/1000)
		
## Question 11 - Find V(phat) and store values		
  for(i in 1:length(population_proportions)){
    var_phat[i] <- (1-population_proportions[i])/ 1000
  }
		
## Question 12 - for significance level of 0.05, create a vector beta_5
	beta_5<-seq(0,100)
	for(i in 1:length(population_proportions)){
	  beta_5[i] <- dbinom(p_5, 1000, population_proportions[i])
	}
		
## Question 13 - for significance level of 0.01, create a vector beta_1
  beta_1 <- (population_proportions - p_1) / (sd(population_proportions)*sqrt(1000))
		
## Question 14 - Create a line for significance level 0.05
  plot(population_proportions, beta_5, col="red", ylim = c(0,1))
  par(new=TRUE)
## Question 15 - Create a line for significance level 0.01. Place line on same plot as in Question 14.  Make sure to export this graph and submit to Gradescope.
  plot(population_proportions,beta_1,  col="blue", ylim = c(0,1))
		
## Question 16 - Estimate the power of the test for each significance level if the true population proportion is 0.63. (remember to copy and paste results)

## Question 17 - Describe the differences between the two graphs and what this means for the power of the test.





